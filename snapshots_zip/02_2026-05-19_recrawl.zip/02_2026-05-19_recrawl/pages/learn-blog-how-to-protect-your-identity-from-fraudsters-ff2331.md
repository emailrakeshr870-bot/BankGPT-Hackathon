2 min read



[Emily Kittle](https://www.dupaco.com/learn/blog/author/emily-kittle)
February 03, 2021


# How to protect your identity from fraudsters

[Fraud & Security](https://www.dupaco.com/learn/blog/tag/fraud-security)

![How to protect your identity from fraudsters](https://www.dupaco.com/hubfs/wordpress-migration/identity-protection-refund-email-graphic-scaled-Jan-24-2026-08-12-38-2231-PM.jpg)

Monitoring your financial accounts and credit report helps you protect yourself from fraud.

If there’s suspicious account activity, you’re the first to know.

As a Dupaco member, you have several tools to keep your accounts—and your identity—safe.

### Suspect fraud?

Contact Dupaco immediately at 800-373-7600 if you:

- Notice suspicious account activity

- Suspect your Dupaco cards are lost or stolen

- Are missing mail or financial statements

- Believe you’re the victim of fraud or identity theft


The sooner we know, the sooner we can help you stop potentially fraudulent activity.

## **Dupaco’s fraud-fighting tools**

#### eNotifier alerts

Get free real-time notifications for ATM transactions, [Shine](https://www.dupaco.com/shine) Online and Mobile Banking sign-ins and more.

To get started, sign in to Shine and select eNotifiers. Under Activity Alerts, enable All Transactions to receive email or text messages for all transactions to your accounts.

#### Bright Track

Access your credit report and credit score for free any time with [Bright Track](https://www.dupaco.com/brighttrack). You should watch for:

- Incorrect personal information

- Inquiries from lenders you don’t recognize

- New accounts you didn’t open


#### Card Security

Quickly disable or report your Dupaco card(s) lost or stolen in Shine Online and Mobile Banking. If you think someone is using your card without your permission, please call Dupaco right away at 800-373-7600.

#### Two-step verification

This free tool helps prevent fraudsters from accessing your account in Shine—even if they manage to get your password.

In addition to your username and password, two-step verification requires a second form of authentication, or proof that it’s you who’s trying to log in. You’ll receive a unique security code—sent via text or email—that you enter each time you sign in.

Never share this unique security code with anyone.

#### Family ID Restoration

The special coverage helps you and your family recover from identity theft should you need it. The [coverage](https://www.dupaco.com/personal/insurance#identity-protection) provides up to $25,000 in expense reimbursement assistance and help restoring your identity with credit bureaus, the Social Security Administration and more.

## **More ways to protect your identity**

Besides using Dupaco’s tools, here are a few other ways you can help keep your identity safe:

#### Set strong passwords

Create passwords using a combination of upper- and lowercase letters, numbers and symbols that do not contain sequences or repeated characters. Don’t use information that can be guessed, like your birth date or Social Security number.

[These tips can take your passwords to the next level >](https://www.dupaco.com/learn/blog/how-to-spring-clean-your-passwords)

#### Protect your personal information

Your Dupaco debit card PIN is yours and yours alone. Never share it. Ever.

The same goes for your Shine password. Dupaco will never ask for it.

#### Practice pausing

If you get a call from a loved one asking for money, pause first.

Scammers will pose as relatives or friends, asking for cash to help in an emergency.

In times of crisis, it might be hard to know if it’s a loved one or a scammer on the other end of the phone or email.

The [Federal Trade Commission](https://www.consumer.ftc.gov/topics/identity-theft) suggests taking these steps to help you determine whether it’s a scam:

- Ask the caller questions a stranger couldn’t possibly answer.

- Call a known phone number belonging to that person.

- Check the story out with someone else in your circle of relatives or friends.


### ![In stressful situations, practice creating time and space to think. Pausing, even if it's just for a minute, will allow your brain to better process the situation.](https://www.dupaco.com/wp-content/uploads/2020/03/how-to-spot-scams-tip-stressful-buy-time-web.jpg?width=676&height=338&name=how-to-spot-scams-tip-stressful-buy-time-web.jpg)

### Know how to spot a scam

Criminals have many ways of tricking you into sharing your personal and financial information. Taking the time to understand their common scams can help you stay protected.

## Recent News

[![Were you contacted about card fraud?](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/Identity-protection-HGicon-676x338.jpg)](https://www.dupaco.com/learn/blog/did-you-get-a-call-about-card-fraud)

January 22, 2021

#### [Were you contacted about card fraud?](https://www.dupaco.com/learn/blog/did-you-get-a-call-about-card-fraud)

If you get a call about potential debit or credit card fraud on your account, hold the phone—it might not be who you think it is.

[Read More](https://www.dupaco.com/learn/blog/did-you-get-a-call-about-card-fraud)

[![Crypto fraud: What you need to know](https://www.dupaco.com/hubfs/wordpress-migration/Protect-AccountsIcon-673x338-1-scaled-Jan-24-2026-08-05-41-1557-PM.jpg)](https://www.dupaco.com/learn/blog/crypto-fraud-what-you-need-to-know)

November 04, 2025

#### [Crypto fraud: What you need to know](https://www.dupaco.com/learn/blog/crypto-fraud-what-you-need-to-know)

Cryptocurrency (or crypto) is a digital form of money that can be exchanged into physical currency to buy “coins” or “tokens” of a type of...

[Read More](https://www.dupaco.com/learn/blog/crypto-fraud-what-you-need-to-know)

[![Dealing with unemployment fraud? Find out what to do next](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/Dupacos-Hands-HGicon-676x338.jpg)](https://www.dupaco.com/learn/blog/dealing-with-unemployment-fraud-find-out-what-to-do-next)

May 21, 2021

#### [Dealing with unemployment fraud? Find out what to do next](https://www.dupaco.com/learn/blog/dealing-with-unemployment-fraud-find-out-what-to-do-next)

Could someone be collecting unemployment benefits in your name? It’s possible. Unemployment fraud continues to grow since the pandemic started. ...

[Read More](https://www.dupaco.com/learn/blog/dealing-with-unemployment-fraud-find-out-what-to-do-next)

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/learn/blog/how-to-protect-your-identity-from-fraudsters#) Cancel

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/learn/blog/how-to-protect-your-identity-from-fraudsters#) Cancel

Twitter Widget Iframe

Third Party Plugins

Messenger Launcher

Messenger