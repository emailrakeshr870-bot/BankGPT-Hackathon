1 min read



[Emily Kittle](https://www.dupaco.com/learn/blog/author/emily-kittle)
December 27, 2017


# Why should you properly insure those expensive gifts?

[Insurance](https://www.dupaco.com/learn/blog/tag/insurance)

![Why should you properly insure those expensive gifts?](https://www.dupaco.com/hubfs/wordpress-migration/Money-protected-HGicon-676x338-1-Jan-24-2026-08-17-54-5705-PM.jpg)

If you’ve ever been gifted jewelry, drones or other valuable pieces, it’s worth considering how to protect them. Should you insure expensive gifts?

It can be easy to overlook the importance of insuring them, according to [Dupaco Insurance Services](https://www.dupaco.com/personal/insurance).

And here’s why: Because they’re gifts, and you don’t have any money in them yourself, the value can sneak up on you sometimes and surprise you.

## **Gifts that can affect your insurance**

These more expensive gifts are worth considering protecting with insurance:

- Jewelry

- Firearms

- Collectibles

- Fine art

- Drones


Homeowner’s and renters insurance policies limit the amount of property coverage for these items.

But most Dupaco Insurance Services carriers offer the option to add a scheduled property rider to your policy that provides all-risk coverage for listed items—such as jewelry, fine art and firearms—up to their appraised value. The endorsement includes mysterious disappearance.

## **What you should know about drones**

If you buy or receive a drone, how you use it determines whether you need additional insurance.

If it will be used for commercial purposes, like wedding photography, neither a homeowner’s policy nor a commercial policy will respond.

Instead, you need a commercial drone policy to protect your gift.

Is it for personal use? Your homeowner’s policy will cover damage to the drone or liability up to your policy limits in the event it crashes into someone’s property.

But if you are renting and don’t have renters insurance, you don’t have that liability coverage.

[Request your free insurance quote >](https://www.dupaco.com/insure)

## Recent News

[![4 budget-friendly gift ideas](https://www.dupaco.com/hubfs/wordpress-migration/carsyn-Houtakker-web-1.jpg)](https://www.dupaco.com/learn/blog/4-budget-friendly-gift-ideas)

November 08, 2022

#### [4 budget-friendly gift ideas](https://www.dupaco.com/learn/blog/4-budget-friendly-gift-ideas)

Feeling pressured to give the perfect gift?

[Read More](https://www.dupaco.com/learn/blog/4-budget-friendly-gift-ideas)

[![Dupaco’s Gift of Innovation strengthens nonprofits](https://www.dupaco.com/hubfs/wordpress-migration/Waypoint-Innovation-Lab-senior-management-team-and-board-members-scaled-4.jpg)](https://www.dupaco.com/learn/blog/dupacos-gift-of-innovation-strengthens-nonprofits)

September 16, 2025

#### [Dupaco’s Gift of Innovation strengthens nonprofits](https://www.dupaco.com/learn/blog/dupacos-gift-of-innovation-strengthens-nonprofits)

Fixing the leaks is important—but building a better boat? That’s where the magic happens. Facing the aftermath of the pandemic, Derecho, economic...

[Read More](https://www.dupaco.com/learn/blog/dupacos-gift-of-innovation-strengthens-nonprofits)

[![Meet your #DupacoCrew: ‘I am blessed with the best’](https://www.dupaco.com/hubfs/wordpress-migration/DUP_1453-676x338-web-1.jpg)](https://www.dupaco.com/learn/blog/meet-your-dupacocrew-i-am-blessed-with-the-best)

February 10, 2022

#### [Meet your \#DupacoCrew: ‘I am blessed with the best’](https://www.dupaco.com/learn/blog/meet-your-dupacocrew-i-am-blessed-with-the-best)

By Sailu Aryal \| Corporate governance specialist I came to the United States 17 years ago with two suitcases of clothes, college partially paid for...

[Read More](https://www.dupaco.com/learn/blog/meet-your-dupacocrew-i-am-blessed-with-the-best)

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/learn/blog/properly-protecting-your-new-gifts#) Cancel

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/learn/blog/properly-protecting-your-new-gifts#) Cancel

Twitter Widget Iframe

Third Party Plugins

Messenger Launcher

Messenger