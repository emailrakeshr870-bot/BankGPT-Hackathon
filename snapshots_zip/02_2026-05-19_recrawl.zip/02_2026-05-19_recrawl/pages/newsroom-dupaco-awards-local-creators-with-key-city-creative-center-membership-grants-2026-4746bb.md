1 min read



[Emily Kress](https://www.dupaco.com/newsroom/author/emily-kress)
January 08, 2026


# Dupaco awards local creators with Key City Creative Center membership grants

![Dupaco awards local creators with Key City Creative Center membership grants](https://www.dupaco.com/hubfs/wordpress-migration/placeholder-no-image.png)

DUBUQUE, Iowa — Through a partnership with [Key City Creative Center](https://keycitycreativecenter.org/) (KCCC), Dupaco Credit Union is empowering four community members by providing resources to create, develop products and connect with other local makers, artists and entrepreneurs, potentially paving the way for small business opportunities.

Dupaco has awarded four individuals with 6-month memberships to KCCC to develop their skills and training. Those selected to receive the memberships are: Debra Hayes, Adrian Funk, Jillian Funk and Rodrigo Marin.

Key City Creative Center is a dynamic makerspace where members can create and collaborate on projects and ideas. The center provides equipment and classes in woodworking, welding, metalworking, 3-D printing, pottery and sewing.

“By providing these membership grants, we’re empowering individuals to develop hands-on skills that can spark innovation and even open doors to small business ventures,” said Joe Hearn, President and CEO of Dupaco. “Access to Key City Creative Center’s tools and collaborative environment gives these creators the resources and confidence to turn ideas into tangible opportunities.”

Applicants completed a questionnaire to apply for the membership grant, and judging was based on the applicants’ desire to improve their skills and their plans for sustaining those skills.

As a credit union benefit, all Dupaco members receive a $10 discount off monthly KCCC membership fees.

###

**ABOUT DUPACO COMMUNITY CREDIT UNION**

Dupaco Community Credit Union is a not-for-profit, member-owned financial cooperative headquartered in Dubuque, Iowa. It is dedicated to the financial well-being of its members, and specializes in personalized financial counseling, money advice and education. It offers savings, loans, investments, insurance and wealth management products for individuals and businesses. Dupaco serves residents in 118 counties throughout Iowa, northwest Illinois and southwest Wisconsin. Founded in 1948 by ten Dubuque Packing Company employees, membership has grown to more than 178,000 with assets exceeding $3.5 billion. It has over 600 employees and 23 branch office locations. Learn more at www.dupaco.com.

## Recent News

[![Dupaco awards local creators with Key City Creative Center membership grants](https://www.dupaco.com/hubfs/wordpress-migration/placeholder-no-image.png)](https://www.dupaco.com/newsroom/dupaco-awards-local-creators-with-key-city-creative-center-membership-grants)






1 min read

January 13, 2025

#### [Dupaco awards local creators with Key City Creative Center membership grants](https://www.dupaco.com/newsroom/dupaco-awards-local-creators-with-key-city-creative-center-membership-grants)

DUBUQUE, Iowa— Through a partnership with Key City Creative Center (KCCC), Dupaco Credit Union is empowering three community members by providing...

[Read More](https://www.dupaco.com/newsroom/dupaco-awards-local-creators-with-key-city-creative-center-membership-grants)

[![Dupaco supports local creators and entrepreneurs with grants to Key City Creative Center](https://www.dupaco.com/hubfs/wordpress-migration/placeholder-no-image.png)](https://www.dupaco.com/newsroom/dupaco-supports-local-creators-and-entrepreneurs-with-grants-to-key-city-creative-center)






1 min read

October 16, 2025

#### [Dupaco supports local creators and entrepreneurs with grants to Key City Creative Center](https://www.dupaco.com/newsroom/dupaco-supports-local-creators-and-entrepreneurs-with-grants-to-key-city-creative-center)

DUBUQUE, Iowa— Dupaco Credit Union, in partnership with Key City Creative Center (KCCC), is now accepting applications for three six-month membership...

[Read More](https://www.dupaco.com/newsroom/dupaco-supports-local-creators-and-entrepreneurs-with-grants-to-key-city-creative-center)

[![Dupaco supports local creators and entrepreneurs with Key City Creative Center membership grants](https://www.dupaco.com/hubfs/wordpress-migration/KCCC-homepage-winner-announcement-e1654630911299-Apr-02-2026-04-03-01-2417-AM.jpg)](https://www.dupaco.com/newsroom/dupaco-supports-local-creators-and-entrepreneurs-with-key-city-creative-center-membership-grants)






1 min read

October 16, 2024

#### [Dupaco supports local creators and entrepreneurs with Key City Creative Center membership grants](https://www.dupaco.com/newsroom/dupaco-supports-local-creators-and-entrepreneurs-with-key-city-creative-center-membership-grants)

DUBUQUE, Iowa— Dupaco Credit Union, in partnership with Key City Creative Center (KCCC), is now accepting applications for three six-month KCCC...

[Read More](https://www.dupaco.com/newsroom/dupaco-supports-local-creators-and-entrepreneurs-with-key-city-creative-center-membership-grants)

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/newsroom/dupaco-awards-local-creators-with-key-city-creative-center-membership-grants-2026#) Cancel

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/newsroom/dupaco-awards-local-creators-with-key-city-creative-center-membership-grants-2026#) Cancel

Third Party Plugins

Messenger Launcher

Messenger