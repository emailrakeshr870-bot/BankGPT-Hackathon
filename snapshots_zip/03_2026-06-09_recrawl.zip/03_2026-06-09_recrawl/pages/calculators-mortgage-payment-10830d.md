# Mortgage Payment Calculator

![Homeownership-HGicon-676x338](https://www.dupaco.com/hs-fs/hubfs/Homeownership-HGicon-676x338.jpg?width=2000&height=1000&name=Homeownership-HGicon-676x338.jpg)

Mortgage Payment

Principal, interest, insurance and more... We’ll break it all down here.

Loan Information

Home price

$300,000

Down payment

$60,000

Loan term

10 years

15 years

20 years

30 years

Interest rate

Assumptions

Include PMI

Include Taxes & Insurance

Property tax

$5,550

Home insurance (annual)

HOA dues (monthly)

Your estimated monthly mortgage payment is

$2,065.

[Apply for a loan](https://homeloans.dupaco.com/)

[Compare rates](https://www.dupaco.com/personal/loans/home-loans#rates)

Breakdown

Schedule

Total$2,065

P&I

Taxes

Insurance

![Organization logo](https://storage.googleapis.com/chimney-calculators/production%2Fcontent%2Forganization%2F332%2Flogo%2Flogo?v=1713820105563)[powered by\\
![chimney logo](https://storage.googleapis.com/chimney-calculators/production%2Fcontent%2Forganization%2F201%2Flogo%2Flogo)](https://www.chimney.io/?utm_source=live-calculator-https://www.dupaco.com/calculators/mortgage-payment "financial calculator website")

Disclosure

Estimating your monthly [home loan](https://www.dupaco.com/personal/loans/home-loans?hsLang=en) payment before starting your search for a new home can boost your negotiating power and help you choose the best loan for your budget. If your search for a home is getting serious, it’s always best to consult a mortgage loan officer. In the meantime, use this free mortgage payment calculator to get an idea of your monthly mortgage payment based on the purchase price and other factors.

_More for you_: Check out these[free resources](https://www.dupaco.com/learn/blog?hsLang=en)to help you buy your first home.

## Handpicked for You

[What’s the best way to deal with an escrow shortage?](https://www.dupaco.com/learn/blog/whats-the-best-way-to-deal-with-an-escrow-shortage?hsLang=en)

[**What’s the best way to deal with an escrow shortage?**](https://www.dupaco.com/learn/blog/whats-the-best-way-to-deal-with-an-escrow-shortage?hsLang=en)

Nov 21, 2025

If you use an escrow account to help manage the costs of homeownership, you might have recently learned that you have an escrow...

[Should I get a HELOC just in case? Here’s what to consider](https://www.dupaco.com/learn/blog/should-i-get-a-heloc-just-in-case-heres-what-to-consider?hsLang=en)

[**Should I get a HELOC just in case? Here’s what to consider**](https://www.dupaco.com/learn/blog/should-i-get-a-heloc-just-in-case-heres-what-to-consider?hsLang=en)

May 2, 2025

Life can be unpredictable—and expensive. Maybe it’s a sudden roof repair, an emergency medical bill or a job change you didn’t...

[Building stability through homeownership: Iowa Heartland Habitat for Humanity](https://www.dupaco.com/learn/blog/revitalizing-neighborhoods-and-making-affordable-housing-and-homeownership-possible?hsLang=en)

[**Building stability through homeownership: Iowa Heartland Habitat for Humanity**](https://www.dupaco.com/learn/blog/revitalizing-neighborhoods-and-making-affordable-housing-and-homeownership-possible?hsLang=en)

Jan 6, 2026

When the Walnut Neighborhood Association reached out to Iowa Heartland Habitat for Humanity in 2016, the historic Waterloo...

[Read more](https://www.dupaco.com/resources/personal-resources?hsLang=en)

✕

[Continue](https://www.dupaco.com/calculators/mortgage-payment#) Cancel

✕

[Continue](https://www.dupaco.com/calculators/mortgage-payment#) Cancel