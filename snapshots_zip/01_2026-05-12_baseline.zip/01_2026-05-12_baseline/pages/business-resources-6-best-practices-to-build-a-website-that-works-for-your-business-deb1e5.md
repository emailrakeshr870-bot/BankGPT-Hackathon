3 min read



[Emily Kittle](https://www.dupaco.com/business/resources/author/emily-kittle)
September 14, 2022


# 6 best practices to build a website that works for your business

[Growth](https://www.dupaco.com/business/resources/tag/growth) [Leadership & HR](https://www.dupaco.com/business/resources/tag/leadership-hr)

![6 best practices to build a website that works for your business](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/Seminars-educate-HGicon-676x338.jpeg)

Whether you own a clothing store, food truck or consulting company, a website plays a critical role in your small business.

[Studies](https://www.inc.com/replacemeplease1456141668.html#:~:text=%22Studies%20have%20shown%20that%20over,usually%20by%20visiting%20its%20website.) show that more than 70-80% of people will research a company online before purchasing. And they usually get that information by visiting the company’s website.

Even if you don’t have a website, your company might already have an online presence. The problem? You don’t get to control the narrative of your business when it’s mentioned on social media, online reviews and other websites.

Having a website is one way you can manage what customers and potential customers see and hear about your business.

Whether you’re building your website from scratch or improving an existing one, we’ve got six best practices to help you create a site that works for your business. These tips come fresh from a recent expert panel discussion about Website Best Practices, courtesy of Dupaco’s Virtual Business Lab.

[Watch the full panel discussion >](https://www.ruralideas.net/panel-discussions)

## **\|1\| Determine your goals**

Just like you did with your business, you need to think about the goals of your website—and why you’re creating it.

Thinking through your website’s purpose will help you build a site that best serves your business. Ask yourself these questions to help you identify that purpose:\[/vc\_column\_text\]\[vc\_empty\_space\]

- What does my business offer?

- What problem does my business solve for others?

- What action do I want people to take when they visit my website? (Make a purchase? Request a consultation? Learn how to visit my physical store?)


- What do I want this employee to do for me?

- Does this employee sell my products or services?

- Do I need this employee to tell people who I am?


And if you’re a new business owner, creating your website gives you another place to figure out more about who you are and what you offer. As your company grows and changes, the purpose of your website will evolve too.

[Sign up for a free website design bootcamp >](https://www.dupaco.com/business/resources/free-website-design-bootcamp)

## **\|2\| Know who should create your website**

Just like filing taxes, you’ll need to decide whether you’re creating your website or hiring someone to do it for you.

Ultimately, this decision comes down to your time, budget, aptitude and comfort level.

If you detest technology and have the budget, you might be better off hiring an expert to help you. But if you’re fairly tech-savvy and have the time and interest, many online programs can guide you through the creation phase.

If you hire someone to do the job for you, you’ll still want to understand what they’re doing, why they’re doing it and how to manage your site moving forward. It’s still your website, so you’ll need to know how to maintain and update it.

## **\|3\| Feature clear calls to action**

Think back to the purpose and goals of your website. What do you want people to do when they visit: Buy a product or service? Fill out a form?

Whatever your goal is, tell your visitors clearly and concisely. Otherwise, your visitors won’t take that action.

Here are some examples of clear calls to action:\[/vc\_column\_text\]\[vc\_empty\_space\]

- Buy now

- Download the guide

- Shop the sale

- Request a quote


Unlike a physical store, there’s more than one way to access your website. So you’ll want to include these calls to action throughout your web pages. This way, visitors will know what they’re supposed to do no matter which door they enter.

One word of caution, though: Don’t include too many different calls to action on the same page. Otherwise, you risk overwhelming visitors and losing them.

## **\|4\| Optimize your website for search engines**

You want people to find your business online. And optimizing your website for search engines is an important step in that process.

What does that mean? When people Google a search term related to your business, you want the search engine to suggest your company’s website as a result.

Search Engine Optimization is a bit mysterious, but there are key steps you can take to help search engines understand what your website is about to help guide people to your site:

- Write clear and compelling copy.

- Know your customers.

- Use words and phrases that your customers would use to search for your products or services.

- Update your website with fresh content.


[Hear more expert SEO tips from the discussion >](https://www.ruralideas.net/panel-discussions)

## **\|5\| Make your website mobile-friendly**

Your site might look great on a computer. But how does it look when you visit it on your phone?

More than half of website traffic comes from a mobile device, according to [Statista](https://www.statista.com/statistics/277125/share-of-website-traffic-coming-from-mobile-devices/). So it’s important to make your website mobile-friendly. You want it to both look and perform well for someone landing on it from their phone.

Otherwise, they won’t have the experience you were hoping for.

## **\|6\| Start small**

Your first version of your website does not need to be complicated.

You can start small. It can be one beautiful, well-functioning page built to grow with your business.

While you want it to look good, don’t get lost in the perfection of the details. It doesn’t need to be the perfect color, the perfect font or the perfect image. Instead, you want to keep moving forward.

Get it out there and come back to it.

Just like your business, your website will evolve. And you can keep refining who you are and what you want to share with the world.

[Watch the panel discussion for more best practices >](https://www.ruralideas.net/panel-discussions)

## Recent News

[![4 tips to help you consider how to finance your business](https://www.dupaco.com/hubfs/wordpress-migration/Jumble-TanyaM-George-20181203-980x450-1-Jan-24-2026-08-00-51-6701-PM.jpg)](https://www.dupaco.com/business/resources/4-tips-to-help-you-consider-how-to-finance-your-business)

September 14, 2022

#### [4 tips to help you consider how to finance your business](https://www.dupaco.com/business/resources/4-tips-to-help-you-consider-how-to-finance-your-business)

By Tanya Moore \| Vice president, business lending If thoughts of entrepreneurship have been dancing in your head, you’ve likely experienced a host...

[Read More](https://www.dupaco.com/business/resources/4-tips-to-help-you-consider-how-to-finance-your-business)

[![3 steps to help you start your first podcast](https://www.dupaco.com/hubfs/wordpress-migration/podcast-pilot-recording-tony-viertel-and-dave-klavitter-web-676x338-1-1.jpg)](https://www.dupaco.com/business/resources/3-steps-to-help-you-start-your-first-podcast)

September 14, 2022

#### [3 steps to help you start your first podcast](https://www.dupaco.com/business/resources/3-steps-to-help-you-start-your-first-podcast)

Podcasting can be a great addition to your business’ marketing strategy. After all, about half of the U.S. population has listened to one,...

[Read More](https://www.dupaco.com/business/resources/3-steps-to-help-you-start-your-first-podcast)

[![When's the best time to write a business plan?](https://www.dupaco.com/hubfs/wordpress-migration/Midwest-Girl-editted-980x450-1-4.jpg)](https://www.dupaco.com/business/resources/whens-the-best-time-to-write-a-business-plan-dupaco)

September 14, 2022

#### [When's the best time to write a business plan?](https://www.dupaco.com/business/resources/whens-the-best-time-to-write-a-business-plan-dupaco)

Writing a business plan is an essential part of building a successful business. At its core, a business plan is a road map for your project. It...

[Read More](https://www.dupaco.com/business/resources/whens-the-best-time-to-write-a-business-plan-dupaco)

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/business/resources/6-best-practices-to-build-a-website-that-works-for-your-business#) Cancel

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/business/resources/6-best-practices-to-build-a-website-that-works-for-your-business#) Cancel

Twitter Widget Iframe