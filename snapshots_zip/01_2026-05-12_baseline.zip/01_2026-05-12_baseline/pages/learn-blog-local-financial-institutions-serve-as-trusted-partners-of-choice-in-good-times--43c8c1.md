2 min read



[Emily Kittle](https://www.dupaco.com/learn/blog/author/emily-kittle)
June 05, 2023


# Local financial institutions serve as trusted partners of choice in good times and bad

[Budgeting](https://www.dupaco.com/learn/blog/tag/budgeting) [Community](https://www.dupaco.com/learn/blog/tag/community)

![Local financial institutions serve as trusted partners of choice in good times and bad](https://www.dupaco.com/hubfs/wordpress-migration/Community-HGicon-676x338-1-1.jpg)

_By Joe Hearn \| President & CEO of Dupaco Credit Union_

When Silicon Valley Bank (SVB) collapsed earlier this year, it became the first FDIC-insured institution to fail since 2020 and the largest by assets since Washington Mutual in 2008. While local credit unions and banks are not affected by these recent bank failures, it’s still a critical time to remind tri-state area residents their money is safe and secure.

The collapse of SVB and Signature Bank was due, in large part, to its high percentage of uninsured deposits and mismatched investments.

At the end of their fourth quarter, Silicon Valley Bank had a whopping 93.9% of uninsured deposits. Signature Bank also had a similarly high ratio of 89.7%.

In contrast, deposits at any federally insured financial institution are protected up to $250,000 per individual depositor. Our loan portfolio is diversified to limit the potential impact a downturn in any one element of the economy might have on our operations.

Consumers have never lost a penny of their deposits at an insured institution, including the [13 times](https://www.cnbc.com/2020/04/09/what-happened-in-every-us-recession-since-the-great-depression.html) the United States experienced a recession.

In addition to being insured, Iowa-based credit unions and banks are regularly examined by federal regulators to ensure we remain financially sound. People place their trust in their preferred financial to safeguard their assets, and it’s always been our top responsibility to keep our members’ hard-earned money safe, especially in an economic downturn.

In fact, credit unions were formed as a [solution](https://www.washingtonpost.com/brand-studio/wp/2020/07/02/feature/the-basics-behind-credit-unions/) to the financial crisis during the Great Depression.

In fact, credit unions were formed as a solution to the financial crisis during the Great Depression.

Because of our member-owned structure, we can be authentic advocates for our members’ best interests, even in times of financial uncertainty. It’s our purpose to help people feel capable, confident and less stressed about money.

To clarify, SVB and Signature Bank concentrated on tech start-ups and cryptocurrency companies. These unique business models are not representative of most banks and credit unions in the U.S. financial ecosystem. Additionally, these two banks had a specific customer base, which increased their risk overall.

Being local means we truly understand tri-state area residents’ everyday needs.

Whether that be providing small business loans, offering accounts for all family members or meeting people where they are, it’s clear there is a stark difference.

With more than 1.5 million members (nearly half of Iowa’s population), Iowa-based credit unions have stepped up to support members and champion its philosophy of “people helping people.” Last year alone, we provided 30% of Iowa’s total mortgage loans and helped members save more than $160 million annually through better rates and fewer fees.

In good times or bad, local financial partners have provided a clear path forward, even in a crisis. The local difference means that we step up during all life’s storms to help those in need, and we will continue to meet those needs to help our friends and neighbors save more of their hard-earned money.

_This column originally appeared in the June 4, 2023, [Telegraph Herald](https://www.telegraphherald.com/news/opinion/article_969a87cc-e5f0-11ed-816b-833071fe8bef.html)._

## Recent News

[![4 budget-friendly gift ideas](https://www.dupaco.com/hubfs/wordpress-migration/carsyn-Houtakker-web-1.jpg)](https://www.dupaco.com/learn/blog/4-budget-friendly-gift-ideas)

December 12, 2017

#### [4 budget-friendly gift ideas](https://www.dupaco.com/learn/blog/4-budget-friendly-gift-ideas)

Updated on Nov. 8, 2022, at 8:20 a.m. CT Feeling pressured to give the perfect gift?

[Read More](https://www.dupaco.com/learn/blog/4-budget-friendly-gift-ideas)

[![Getting lower insurance with more coverage was ‘the best experience’](https://www.dupaco.com/hubfs/wordpress-migration/resources-general-email-graphic-scaled-Jan-24-2026-08-09-32-1655-PM.jpg)](https://www.dupaco.com/learn/blog/getting-lower-insurance-with-more-coverage-was-the-best-experience)

March 17, 2023

#### [Getting lower insurance with more coverage was ‘the best experience’](https://www.dupaco.com/learn/blog/getting-lower-insurance-with-more-coverage-was-the-best-experience)

DUBUQUE, Iowa—As a mom, Jessica Klein has many hopes and dreams for her family. But she needed a little help seeing some of them through. She’d...

[Read More](https://www.dupaco.com/learn/blog/getting-lower-insurance-with-more-coverage-was-the-best-experience)

[![23+ creative ways to save money for travel](https://www.dupaco.com/hubfs/wordpress-migration/Travel-on-a-Budget-web-676x338-2024-1.jpg)](https://www.dupaco.com/learn/blog/23-creative-ways-to-save-money-for-travel)

November 27, 2024

#### [23+ creative ways to save money for travel](https://www.dupaco.com/learn/blog/23-creative-ways-to-save-money-for-travel)

Dreaming of your next vacation? With a little planning, you can make that getaway a reality without breaking the bank. We’ve rounded up lots of...

[Read More](https://www.dupaco.com/learn/blog/23-creative-ways-to-save-money-for-travel)

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/learn/blog/local-financial-institutions-serve-as-trusted-partners-of-choice-in-good-times-and-bad#) Cancel

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/learn/blog/local-financial-institutions-serve-as-trusted-partners-of-choice-in-good-times-and-bad#) Cancel

Twitter Widget Iframe