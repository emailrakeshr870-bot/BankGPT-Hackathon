1 min read



[Emily Kittle](https://www.dupaco.com/business/resources/author/emily-kittle)
March 22, 2023


# Family property management business builds on a vision

[Exit/Succession](https://www.dupaco.com/business/resources/tag/exit-succession) [Growth](https://www.dupaco.com/business/resources/tag/growth)

![Family property management business builds on a vision](https://www.dupaco.com/hubfs/wordpress-migration/gantz-family-web-676x338-1-1.jpg)

MADISON, Wis.—Chris Gantz grew up watching his family breathe new life into older properties.

As the Dubuque, Iowa, native got older, he started helping with the renovation projects while attending the University of Wisconsin-Madison.

So, of course when he and his wife, McKenna, bought their first house, they fixed it up—and turned it into an Airbnb.

> “I always knew growing up that I wanted to be involved in this business in some way,” Chris said. “There’s a lot of freedom, but it’s a lot of work.”

## **Property management business is born**

About five years ago, Chris and McKenna started their Waunakee-based property management business, Patriot Properties.

And since then, they’ve brought about 50 investors along with them and their sister company, Patriot Builders—buying, renovating and managing properties of all sizes in Wisconsin.

It’s a business that requires a financial partner.

And early on, Chris’ dad pointed the couple to Dupaco.
![Chris Gantz reads a book to his son, Jackson, in their home. (K. Wolf photo)](https://www.dupaco.com/wp-content/uploads/2023/03/gantz-chris-with-son-web-676x338-1.jpg?width=676&height=338&name=gantz-chris-with-son-web-676x338-1.jpg)Chris Gantz reads a book to his son, Jackson, in their home. (K. Wolf photo)
The Gantzes first used the financial cooperative to refinance some of their [loans](https://www.dupaco.com/business/loans) so they could take out cash to put toward other property investments.

> “That let us supercharge our growth,” Chris said. “We had worked with other lenders. But it was quickly obvious that Dupaco was always willing to do more—better terms and more in-depth discussions about our goals and plans.”

[Try our free business loan repayment calculator >](https://www.dupaco.com/calculators/business-loan-repayment-calculator-dupaco)

## **‘Dupaco understands our vision’**

Their most recent purchase was a $12 million, 129-unit apartment complex just down the road from one of Dupaco’s [Madison branches](https://www.dupaco.com/contact#dupaco-locator-widget_1769206785258).

“We take a lot of pride in everything we have,” Chris said. “We’ll get calls from homeowners in these neighborhoods, thanking us for what we’re doing. Their property values are going up. It’s a great motivator to keep going.”

Chris hopes to continue bringing new property investors along, helping them learn and grow too.

“A lot of what we have been able to achieve is because of Dupaco,” he said. “Dupaco understands our vision. And they have believed in us.”

[Explore our free Business Resource Center >](https://www.dupaco.com/resources/business-resources)

## Recent News

[![IP basics for your business: How to protect intellectual property](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/identity-protection-graphic.jpg)](https://www.dupaco.com/business/resources/ip-basics-for-your-business-how-to-protect-intellectual-property)

June 08, 2022

#### [IP basics for your business: How to protect intellectual property](https://www.dupaco.com/business/resources/ip-basics-for-your-business-how-to-protect-intellectual-property)

Anything you create or build has the potential to be copied by someone else. And depending on how critical your idea is, you might want to protect it...

[Read More](https://www.dupaco.com/business/resources/ip-basics-for-your-business-how-to-protect-intellectual-property)

[![4 questions you’ll want to answer before you sell your business](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/resources-general-email-graphic-scaled-Jan-24-2026-08-16-45-5698-PM.jpg)](https://www.dupaco.com/business/resources/4-questions-youll-want-to-answer-before-you-sell-your-business)

June 17, 2022

#### [4 questions you’ll want to answer before you sell your business](https://www.dupaco.com/business/resources/4-questions-youll-want-to-answer-before-you-sell-your-business)

It’s important to start preparing and organizing to sell your business as early as possible.

[Read More](https://www.dupaco.com/business/resources/4-questions-youll-want-to-answer-before-you-sell-your-business)

[![Letting go: Tips to help you hand over the reins to your business](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/Key-HGicon-676x338.jpg)](https://www.dupaco.com/business/resources/letting-go-tips-to-help-you-hand-over-the-reins-to-your-business)

June 17, 2022

#### [Letting go: Tips to help you hand over the reins to your business](https://www.dupaco.com/business/resources/letting-go-tips-to-help-you-hand-over-the-reins-to-your-business)

As you prepare to sell your business, you’ll need to learn how to hand over the reins to your successor. This is especially crucial when you sell or...

[Read More](https://www.dupaco.com/business/resources/letting-go-tips-to-help-you-hand-over-the-reins-to-your-business)

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/business/resources/family-property-management-business-builds-on-a-vision#) Cancel

✕

**Heads up! This link leads to a different website.**

We only do this when it's helpful for you. But we must inform you that Dupaco isn't responsible for the site's content, products, services, policies or sponsors. Also, Dupaco's Privacy Policy does not apply to third-party sites. So, if you have concerns, please look at its privacy disclosures.

[Continue](https://www.dupaco.com/business/resources/family-property-management-business-builds-on-a-vision#) Cancel

Twitter Widget Iframe