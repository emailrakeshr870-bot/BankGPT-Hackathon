1 min read

[Emily Kittle](https://www.dupaco.com/learn/blog/author/emily-kittle)
December 12, 2025

# You still have time to save in these accounts

[Saving](https://www.dupaco.com/learn/blog/tag/saving) [Investing & Retirement](https://www.dupaco.com/learn/blog/tag/investing-retirement)

![You still have time to save in these accounts](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/Retirement-goals-HGicon-676x338.jpg)

Procrastinators, rejoice!

If you meant to set aside more money for retirement or health expenses in the past year, you still have time.

## **Individual Retirement Accounts**

You’ve heard it before, but it’s worth repeating: The sooner you start saving for retirement, the more money you’ll have later when you need it.

[IRAs](https://www.dupaco.com/personal/retirement) offer a tax-advantaged way to invest—and save—for retirement.

[Did you hear? This law could impact how you save for retirement >](https://www.dupaco.com/learn/blog/5-ways-secure-2-0-act-could-impact-your-retirement-savings)

If you’d still like to contribute to an IRA for 2025, here’s what you need to know:

- Eligible individuals can make contributions to a Traditional or Roth IRA for 2025 until April 15, 2026.
- IRA contributions for the 2025 tax year are limited to $7,000 ($8,000 if you’re 50 or better) or your earned income for the year—whichever is less.
- Individuals of any age can now make Traditional IRA contributions if you (or your spouse, if filing a joint return) earned income during that tax year, thanks to the Setting Every Community Up for Retirement Enhancement Act of 2019 (SECURE Act).
- You could receive a deduction for Traditional contributions or a saver’s tax credit for Traditional or Roth contributions.

[![Comparing retirement saving options: Traditional IRA, roth IRA, and 401(k)](https://www.dupaco.com/wp-content/uploads/2020/01/comparing-retirement-saving-options-1024x571.jpg?width=980&height=546&name=comparing-retirement-saving-options-1024x571.jpg)](https://www.irs.gov/retirement-plans/individual-retirement-arrangements-iras)

[Learn more about IRA guidelines >](https://www.irs.gov/retirement-plans/individual-retirement-arrangements-iras)

## **Health Savings Accounts**

If you have a high-deductible health plan, an HSA can help you set money aside for current and future medical expenses.

To be eligible for an [HSA](https://www.dupaco.com/personal/savings-account), you:

- Must be covered under a high-deductible health plan.
- Can’t be covered by another health plan (with limited exceptions).
- Must not be enrolled in Medicare.
- Can’t be claimed as a dependent on someone else’s tax return.

Next tax season, consider setting up automatic recurring contributions to your IRA and HSA accounts to chip away at your goals throughout the year! And make sure you know about these other [tax savings opportunities](https://www.dupaco.com/learn/blog/deductions-you-may-not-know-about-but-should-be-taking). If you want to contribute to an HSA for 2025, here’s what you need to know:

- Eligible individuals can make contributions to an HSA for 2025 until April 15, 2026.
- For your HSA, you can contribute up to $4,300 for self-only coverage ($5,300 if you’re 55 or better) or $8,550 for family coverage ($9,550 if you’re 55 or better).
- HSA-eligible individuals can make tax-deductible contributions, earn tax-free dividends and withdraw money tax free for qualified medical expenses.
- You don’t have to use all of your HSA funds each year. Your balance carries over—and remains with you regardless of changes in coverage or employment.

[Learn more about HSA guidelines >](https://www.healthcare.gov/high-deductible-health-plan/hdhp-hsa-information/)

_\\* Contact your tax advisor to verify eligibility and contribution limits._

## Handpicked for You

[![Deductions you may not know about (but should be taking)](https://www.dupaco.com/hubfs/wordpress-migration/Filene-March-2-maximizing-deductions-scaled-1.jpeg)](https://www.dupaco.com/learn/blog/deductions-you-may-not-know-about-but-should-be-taking)

December 30, 2025

#### [Deductions you may not know about (but should be taking)](https://www.dupaco.com/learn/blog/deductions-you-may-not-know-about-but-should-be-taking)

It’s a safe bet that no one wants to pay more in taxes than they have to. But often, what we don’t know can hurt us come tax time.

[Keep reading](https://www.dupaco.com/learn/blog/deductions-you-may-not-know-about-but-should-be-taking)

[![How to 'trick' yourself into saving more](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/Savings-HGicon-676x338.jpeg)](https://www.dupaco.com/learn/blog/how-to-trick-yourself-into-saving-more)

December 29, 2025

#### [How to 'trick' yourself into saving more](https://www.dupaco.com/learn/blog/how-to-trick-yourself-into-saving-more)

With inflation high and money tight for so many of us, there’s never been a better time to re-examine how we’re managing our finances and to make...

[Keep reading](https://www.dupaco.com/learn/blog/how-to-trick-yourself-into-saving-more)

[![5 ways SECURE 2.0 Act could impact your retirement savings](https://www.dupaco.com/hubfs/Graphics/Collage%20hero%20graphics/certificate-email-graphic-675x338.jpeg)](https://www.dupaco.com/learn/blog/5-ways-secure-2-0-act-could-impact-your-retirement-savings)

February 15, 2023

#### [5 ways SECURE 2.0 Act could impact your retirement savings](https://www.dupaco.com/learn/blog/5-ways-secure-2-0-act-could-impact-your-retirement-savings)

A new law could impact the way you save and take out money for your retirement.

[Keep reading](https://www.dupaco.com/learn/blog/5-ways-secure-2-0-act-could-impact-your-retirement-savings)

✕

[Continue](https://www.dupaco.com/learn/blog/you-still-have-time-to-save-in-these-accounts#) Cancel

✕

[Continue](https://www.dupaco.com/learn/blog/you-still-have-time-to-save-in-these-accounts#) Cancel